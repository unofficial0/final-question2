﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //Giving file path to check if it exists 
                Console.WriteLine("Enter the Path Name");
                string address = Console.ReadLine();
                //get the no of  files from the given directory
                string[] filePaths = Directory.GetFiles($@"{address}");
                Console.WriteLine("No Of Files In the given Path");
                //display the no of files 
                Console.WriteLine($"{filePaths.Length }");
                //get the  no of folders from the given directory
                int directoryCount = System.IO.Directory.GetDirectories($@"{address}").Length;
                Console.WriteLine("No of Folders in the given path");
                //Display the no of folders 
                Console.WriteLine(directoryCount);
            }
            //file io exceptions
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }

    }

}

